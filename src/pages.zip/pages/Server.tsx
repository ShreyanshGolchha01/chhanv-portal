// src/server.ts
const serverUrl = 'http://localhost/chanv/';

export default serverUrl;
